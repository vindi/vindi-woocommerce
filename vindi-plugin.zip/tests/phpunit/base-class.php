<?php

class Vindi_Test_Base extends \WP_UnitTestCase
{

	protected function getSelf()
	{
		return $this;
	}
}
